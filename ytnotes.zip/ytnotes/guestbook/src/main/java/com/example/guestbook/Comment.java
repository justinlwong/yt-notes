package com.example.guestbook;
import java.lang.String;

class Comment
	{
		public String timestamp; 
		public String content; 
		
		  public Comment() {
			  timestamp = null;
			  content = null;
		  }		
	};